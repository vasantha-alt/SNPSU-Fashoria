from flask import Flask, render_template, request, redirect, flash, session
import sqlite3

app = Flask(__name__)
app.secret_key = "secret123"

# DATABASE INIT
def init_db():
    conn = sqlite3.connect("fashoria.db")
    cur = conn.cursor()
    
    cur.execute('''CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        email TEXT,
        password TEXT
    )''')

    cur.execute('''CREATE TABLE IF NOT EXISTS bookings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        tickets INTEGER,
        total_amount REAL
    )''')

    # Add event column to bookings if missing
    cur.execute("PRAGMA table_info(bookings)")
    cols = [r[1] for r in cur.fetchall()]
    if 'event' not in cols:
        cur.execute("ALTER TABLE bookings ADD COLUMN event TEXT")

    cur.execute('''CREATE TABLE IF NOT EXISTS winners (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        event TEXT,
        position INTEGER,
        user_id INTEGER,
        prize_amount REAL
    )''')

    conn.commit()
    conn.close()

init_db()

@app.context_processor
def inject_nav_counts():
    try:
        conn = sqlite3.connect("fashoria.db")
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM bookings")
        total_bookings = cur.fetchone()[0]
        conn.close()
    except Exception:
        total_bookings = 0
    return {"nav_total_bookings": total_bookings}

# HOME
@app.route('/')
def index():
    return render_template("index.html")

# REGISTER
@app.route('/register', methods=['GET','POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']

        conn = sqlite3.connect("fashoria.db")
        cur = conn.cursor()
        cur.execute("INSERT INTO users(name,email,password) VALUES (?,?,?)",(name,email,password))
        conn.commit()
        conn.close()

        flash("Registered Successfully! Please Login")
        return redirect('/login')

    return render_template("register.html")

# LOGIN
@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        conn = sqlite3.connect("fashoria.db")
        cur = conn.cursor()
        cur.execute("SELECT id, name, email FROM users WHERE email=? AND password=?",(email,password))
        user = cur.fetchone()
        conn.close()

        if user:
            session['user'] = email
            session['user_name'] = user[1]
            return redirect('/dashboard')
        else:
            flash("Invalid Email or Password")

    return render_template("login.html")

# DASHBOARD
@app.route('/dashboard-old')
def dashboard_old():
    if 'user' not in session:
        return redirect('/login')
    return render_template("dashboard.html")

# BOOK EVENT (Unified)
@app.route('/book', methods=['GET', 'POST'])
def book_ticket():
    if 'user' not in session:
        return redirect('/login')
    if request.method == 'POST':
        tickets_str = request.form.get('tickets')
        price_str = request.form.get('price')
        event = request.form.get('event')
        if not tickets_str or not price_str or not event:
            flash("Please select event, tickets and price")
            return render_template("book.html")
        tickets = int(tickets_str)
        price_per_ticket = float(price_str)
        total_amount = tickets * price_per_ticket

        # Resolve user_id from session email
        conn = sqlite3.connect('fashoria.db')
        cur = conn.cursor()
        cur.execute("SELECT id FROM users WHERE email=?", (session['user'],))
        user_row = cur.fetchone()
        user_id = user_row[0] if user_row else None
        if not user_id:
            conn.close()
            flash("User not found. Please login again.")
            return redirect('/login')

        cur.execute("INSERT INTO bookings (user_id, tickets, total_amount, event) VALUES (?, ?, ?, ?)",
                    (user_id, tickets, total_amount, event))
        conn.commit()
        conn.close()
        return redirect('/success')
    return render_template("book.html")

@app.route('/dashboard')
def dashboard():
    if 'user' not in session:
        return redirect('/login')
    conn = sqlite3.connect('fashoria.db')
    cur = conn.cursor()

    cur.execute("SELECT COUNT(*) FROM users")
    total_users = cur.fetchone()[0]

    cur.execute("SELECT COUNT(*) FROM bookings")
    total_bookings = cur.fetchone()[0]

    cur.execute("SELECT SUM(total_amount) FROM bookings")
    total_revenue = cur.fetchone()[0]

    conn.close()

    return render_template("dashboard.html",
                           total_users=total_users,
                           total_bookings=total_bookings,
                           total_revenue=total_revenue)

@app.route('/success')
def success():
    return render_template("success.html")

@app.route('/orders')
def orders():
    if 'user' not in session:
        return redirect('/login')
    conn = sqlite3.connect('fashoria.db')
    cur = conn.cursor()
    cur.execute("SELECT id, user_id, tickets, total_amount, event FROM bookings ORDER BY id DESC")
    rows = cur.fetchall()
    conn.close()
    bookings = [{"id": r[0], "user_id": r[1], "tickets": r[2], "total_amount": r[3], "event": r[4]} for r in rows]
    return render_template("orders.html", bookings=bookings, total=len(bookings))

@app.route('/events-booked')
def events_booked():
    if 'user' not in session:
        return redirect('/login')
    conn = sqlite3.connect('fashoria.db')
    cur = conn.cursor()
    cur.execute("SELECT id, user_id, tickets, total_amount, event FROM bookings ORDER BY id DESC")
    rows = cur.fetchall()
    conn.close()
    bookings = [{"id": r[0], "user_id": r[1], "tickets": r[2], "total_amount": r[3], "event": r[4]} for r in rows]
    return render_template("orders.html", bookings=bookings, total=len(bookings))

@app.route('/orders/<int:booking_id>')
def order_detail(booking_id):
    if 'user' not in session:
        return redirect('/login')
    conn = sqlite3.connect('fashoria.db')
    cur = conn.cursor()
    cur.execute("SELECT id, user_id, tickets, total_amount, event FROM bookings WHERE id=?", (booking_id,))
    row = cur.fetchone()
    conn.close()
    if not row:
        return redirect('/orders')
    booking = {"id": row[0], "user_id": row[1], "tickets": row[2], "total_amount": row[3], "event": row[4]}
    return render_template("order_detail.html", booking=booking)

@app.route('/admin/winners', methods=['GET','POST'])
def admin_winners():
    if 'user' not in session:
        return redirect('/login')
    conn = sqlite3.connect('fashoria.db')
    cur = conn.cursor()
    cur.execute("SELECT DISTINCT event FROM bookings WHERE event IS NOT NULL")
    events = [r[0] for r in cur.fetchall()]
    selected_event = request.args.get('event') or (events[0] if events else 'Fashion Walk')
    if request.method == 'POST':
        selected_event = request.form.get('event') or selected_event
        pos1 = request.form.get('pos1')
        pos2 = request.form.get('pos2')
        pos3 = request.form.get('pos3')
        p1 = request.form.get('prize1')
        p2 = request.form.get('prize2')
        p3 = request.form.get('prize3')
        cur.execute("DELETE FROM winners WHERE event=?", (selected_event,))
        if pos1:
            cur.execute("INSERT INTO winners(event, position, user_id, prize_amount) VALUES (?,?,?,?)",
                        (selected_event, 1, int(pos1), float(p1 or 0)))
        if pos2:
            cur.execute("INSERT INTO winners(event, position, user_id, prize_amount) VALUES (?,?,?,?)",
                        (selected_event, 2, int(pos2), float(p2 or 0)))
        if pos3:
            cur.execute("INSERT INTO winners(event, position, user_id, prize_amount) VALUES (?,?,?,?)",
                        (selected_event, 3, int(pos3), float(p3 or 0)))
        conn.commit()
        conn.close()
        return redirect(f'/winners?event={selected_event}')
    cur.execute("SELECT DISTINCT b.user_id, u.name, u.email FROM bookings b LEFT JOIN users u ON u.id = b.user_id WHERE b.event=? ORDER BY u.name IS NULL, u.name, u.email", (selected_event,))
    participants = [{"user_id": r[0], "name": r[1], "email": r[2]} for r in cur.fetchall()]
    conn.close()
    return render_template("admin_winners.html", participants=participants, events=events, selected_event=selected_event)

@app.route('/winners')
def winners():
    conn = sqlite3.connect('fashoria.db')
    cur = conn.cursor()
    cur.execute("SELECT DISTINCT event FROM bookings WHERE event IS NOT NULL")
    events = [r[0] for r in cur.fetchall()]
    selected_event = request.args.get('event') or (events[0] if events else 'Fashion Walk')
    cur.execute("SELECT w.position, w.prize_amount, u.name, u.email FROM winners w LEFT JOIN users u ON u.id = w.user_id WHERE w.event=? ORDER BY w.position ASC", (selected_event,))
    rows = cur.fetchall()
    conn.close()
    winners_list = [{"position": r[0], "prize_amount": r[1], "name": r[2], "email": r[3]} for r in rows]
    return render_template("winners.html", winners=winners_list, events=events, selected_event=selected_event)
# LOGOUT
@app.route('/logout')
def logout():
    session.pop('user',None)
    return redirect('/login')

if __name__ == "__main__":
    app.run(debug=True)
